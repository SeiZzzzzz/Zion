<!DOCTYPE html>
<html>
<head>
		<title> << ZION: DOWN TO NOTHING -- MiniLD#32 -- Multiplayer game >> </title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<style type="text/css" media="screen">
		html, body { height:100%; background-color: #000000; font-family:Tahoma; color:#ffffff;}
		body { margin:0; padding:0; overflow:hidden; }
		#flashContent {  }
		i a { font-size:22px; color:#ff0000;}
		small a { font-size:11px; color:#000000;}
		</style>
</head>	
<body style="">
		<center>ZION: DOWN TO NOTHING -- MiniLD#32 -- Multiplayer game</center>
		<div id="flashContent" style="position:absolute;left:50%;top:30px;margin-left:-400px;">
			<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="800" height="500" id="gigaminer" align="middle">
				<param name="movie" value="/swf/gigaminer.swf" />
				<param name="quality" value="high" />
				<param name="bgcolor" value="#fefffc" />
				<param name="play" value="true" />
				<param name="loop" value="true" />
				<param name="wmode" value="window" />
				<param name="scale" value="showall" />
				<param name="menu" value="true" />
				<param name="devicefont" value="false" />
				<param name="salign" value="" />
				<param name="allowScriptAccess" value="sameDomain" />
				<!--[if !IE]>-->
				<object type="application/x-shockwave-flash" data="/swf/gigaminer.swf" width="800" height="500">
					<param name="movie" value="/swf/gigaminer.swf" />
					<param name="quality" value="high" />
					<param name="bgcolor" value="#fefffc" />
					<param name="play" value="true" />
					<param name="loop" value="true" />
					<param name="wmode" value="window" />
					<param name="scale" value="showall" />
					<param name="menu" value="true" />
					<param name="devicefont" value="false" />
					<param name="salign" value="" />
					<param name="allowScriptAccess" value="sameDomain" />
				<!--<![endif]-->
					<a href="http://www.adobe.com/go/getflash">
						<img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" />
					</a>
				<!--[if !IE]>-->
				</object>
				<!--<![endif]-->
			</object>
		</div>

</body>
</html>