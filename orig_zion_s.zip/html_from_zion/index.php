<!DOCTYPE html>
<html>
<head>
		<title> << ZION: DOWN TO NOTHING -- MiniLD#32 -- Multiplayer game >> </title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<style type="text/css" media="screen">
		html, body { height:100%; background-color: #000000; font-family:Tahoma; color:#ffffff;}
		body { margin:0; padding:0; }
		#flashContent {  }
		i a { font-size:22px; color:#ff0000;}
		small a { font-size:11px; color:#000000;}
		</style>
</head>	
<body style="">

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/ru_RU/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

		<center>ZION: DOWN TO NOTHING -- MiniLD#32 -- Multiplayer game</center>
		<div id="flashContent" style="position:absolute;left:50%;top:30px;margin-left:-400px;">
			<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="800" height="500" id="gigaminer" align="middle">
				<param name="movie" value="/swf/gigaminer.swf?2" />
				<param name="quality" value="high" />
				<param name="bgcolor" value="#fefffc" />
				<param name="play" value="true" />
				<param name="loop" value="true" />
				<param name="wmode" value="window" />
				<param name="scale" value="showall" />
				<param name="menu" value="true" />
				<param name="devicefont" value="false" />
				<param name="salign" value="" />
				<param name="allowScriptAccess" value="sameDomain" />
				<!--[if !IE]>-->
				<object type="application/x-shockwave-flash" data="/swf/gigaminer.swf?2" width="800" height="500">
					<param name="movie" value="/swf/gigaminer.swf?2" />
					<param name="quality" value="high" />
					<param name="bgcolor" value="#fefffc" />
					<param name="play" value="true" />
					<param name="loop" value="true" />
					<param name="wmode" value="window" />
					<param name="scale" value="showall" />
					<param name="menu" value="true" />
					<param name="devicefont" value="false" />
					<param name="salign" value="" />
					<param name="allowScriptAccess" value="sameDomain" />
				<!--<![endif]-->
					<a href="http://www.adobe.com/go/getflash">
						<img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" />
					</a>
				<!--[if !IE]>-->
				</object>
				<!--<![endif]-->
			</object>
			<BR>
			First version of a game is coded on MiniLD#32 in 48 hours.<br>
			<br>
			...and the game is developing right now!<br>
			<br>
			After MiniLD#32:<br>
			<br>
			7 apr 2012 16:18 ЭТОТ СЕРВЕР ТЕПЕРЬ ТЕСТОВЫЙ ДЛЯ РАЗРАБОТКИ ШАХТ.<br> Игра часто будет недоступна. Играйте в <a href="http://vk.com/app2844166">ШАХТЫ</a><br>
			3 apr 2012 22:04 WE ARE IN KONTAKTUS!!! <a href="http://vk.com/app2844166">ШАХТЫ на vk.com</a> <br>
			18 mar 2012 11:08 Restoration of classic soil at start.<br>
			17 mar 2012 19:45 CRYSTAL TREE is added. CRYSTAL TREE is growing every 20 minutes.<br>
			16 mar 2012 8:50 KILLER is added. KILLER destroys heighbour blocks every 6 seconds.<br>
			16 mar 2012 8:50 HARD RED BLOCKS is added.<br>
			16 mar 2012 8:50 COMBOs is added.<br>
			14 mar 2012. 14:01 GREY GOO is added. GREY GOO is self-replicating every 77 seconds!!!!!<br>
			10 mar 2012. 12:00 Making clone >> VK. Делаем клон игры для vkontakte.ru....<br>
			7 mar 2012. 5:35 31st frame bug is fixed.<br>
			7 mar 2012. 5:30 Yellow frame bug is fixed.<br>
			1 mar 2012. 14:28 Digging is slower but rocks are easier.<br>
			1 mar 2012. 14:27 LIQUID MAGMA is added.<br>
			29 feb 2012. 9:39 'Players online' counter is added.<br>
			29 feb 2012. 9:36 Preloader bug is fixed.<br>
			29 feb 2012. 9:22 Hint about controls is added.<br>
			29 feb 2012. 8:36 LOCAL CHAT CHAT CHAT!!!! PRESS 'T'. (very far messages are hidden)<br>
			29 feb 2012. 8:06 Allow cyrillic nicknames.<br>
			29 feb 2012. 8:03 Focus losing bug is fixed.<br>
			29 feb 2012. 5:17 MATRIX:RELOADING - new mine is generated.<br>
			29 feb 2012. 4:47 Bug with "." instead nickname is fixed.<br>
			29 feb 2012. 4:42 Bug with bad gravity on the edges is fixed.<br> 
			29 feb 2012. 4:13 Bug with blue and invisible sand is fixed.<br>
			
			
			
			
			
			
			<br>
			<br>
			<hr><br>
			<br>
			<br>
			<center>>> ideas thinks thanx here: <<<br></center>
			<br>
			<div class="fb-comments" data-href="http://minild32.myachin.com/" data-num-posts="10" data-width="800" data-colorscheme="dark"></div>
		</div>

</body> 
</html>